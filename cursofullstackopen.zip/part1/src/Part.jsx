const Part = ({ parte, exercise }) => {
  return (
    <div>
      <p>
        {parte} {exercise}
      </p>
    </div>
  );
};

export default Part;
